import { useState, useEffect, useRef } from 'react';
import { FlipDigit } from './FlipDigit';
import { RotateCcw, Play, Pause } from 'lucide-react';

interface TimerScreenProps {
  tileColor: string;
  textColor: string;
  backgroundColor: string;
  backgroundImage?: string;
  fontFamily: string;
  subFontSize: string;
  subFontFamily: string;
}

export function TimerScreen({
  tileColor,
  textColor,
  backgroundColor,
  backgroundImage,
  fontFamily,
  subFontSize,
  subFontFamily
}: TimerScreenProps) {
  const [seconds, setSeconds] = useState(0);
  const [isRunning, setIsRunning] = useState(false);
  const intervalRef = useRef<NodeJS.Timeout | null>(null);

  useEffect(() => {
    if (isRunning) {
      intervalRef.current = setInterval(() => {
        setSeconds((prev) => prev + 1);
      }, 1000);
    } else {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
      }
    }
    return () => {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
      }
    };
  }, [isRunning]);

  const minutes = Math.floor(seconds / 60);
  const remainingSeconds = seconds % 60;

  const handleReset = () => {
    setIsRunning(false);
    setSeconds(0);
  };

  const handleToggle = () => {
    setIsRunning(!isRunning);
  };

  const minutesValue = String(minutes).padStart(2, '0');
  const secondsValue = String(remainingSeconds).padStart(2, '0');

  return (
    <div
      className="w-full h-full flex flex-col items-center justify-center px-4"
      style={{
        backgroundColor,
        backgroundImage: backgroundImage ? `url(${backgroundImage})` : undefined,
        backgroundSize: 'cover',
        backgroundPosition: 'center'
      }}
    >
      <div className="flex gap-4 md:gap-6 mb-12">
        <div className="w-[45vw] md:w-[40vw] max-w-md" style={{ aspectRatio: '1 / 1' }}>
          <FlipDigit
            value={minutesValue}
            tileColor={tileColor}
            textColor={textColor}
            fontFamily={fontFamily}
            topContent={<div>분</div>}
            subFontSize={subFontSize}
            subFontFamily={subFontFamily}
            subTextColor={textColor}
          />
        </div>

        <div className="w-[45vw] md:w-[40vw] max-w-md" style={{ aspectRatio: '1 / 1' }}>
          <FlipDigit
            value={secondsValue}
            tileColor={tileColor}
            textColor={textColor}
            fontFamily={fontFamily}
            topContent={<div>초</div>}
            subFontSize={subFontSize}
            subFontFamily={subFontFamily}
            subTextColor={textColor}
          />
        </div>
      </div>

      <div className="flex gap-6 md:gap-10">
        <button
          onClick={handleReset}
          className="p-4 md:p-6 rounded-full bg-white/10 hover:bg-white/20 transition-colors shadow-lg"
          style={{ backgroundColor: tileColor }}
        >
          <RotateCcw className="w-8 h-8 md:w-10 md:h-10" style={{ color: textColor }} />
        </button>

        <button
          onClick={handleToggle}
          className="p-4 md:p-6 rounded-full bg-white/10 hover:bg-white/20 transition-colors shadow-lg"
          style={{ backgroundColor: tileColor }}
        >
          {isRunning ? (
            <Pause className="w-8 h-8 md:w-10 md:h-10" style={{ color: textColor }} />
          ) : (
            <Play className="w-8 h-8 md:w-10 md:h-10" style={{ color: textColor }} />
          )}
        </button>
      </div>
    </div>
  );
}
