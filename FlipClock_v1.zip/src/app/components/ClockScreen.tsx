import { useState, useEffect } from 'react';
import { FlipDigit } from './FlipDigit';

interface ClockScreenProps {
  tileColor: string;
  textColor: string;
  backgroundColor: string;
  backgroundImage?: string;
  fontFamily: string;
  subFontSize: string;
  subFontFamily: string;
  showAmPm: boolean;
  showSeconds: boolean;
  onToggleAmPm: () => void;
  onToggleSeconds: () => void;
}

export function ClockScreen({
  tileColor,
  textColor,
  backgroundColor,
  backgroundImage,
  fontFamily,
  subFontSize,
  subFontFamily,
  showAmPm,
  showSeconds,
  onToggleAmPm,
  onToggleSeconds
}: ClockScreenProps) {
  const [time, setTime] = useState(new Date());

  useEffect(() => {
    const interval = setInterval(() => {
      setTime(new Date());
    }, 1000);
    return () => clearInterval(interval);
  }, []);

  const hours = time.getHours();
  const minutes = time.getMinutes();
  const seconds = time.getSeconds();
  const isPM = hours >= 12;
  const displayHours = hours % 12 || 12;

  const month = String(time.getMonth() + 1).padStart(2, '0');
  const day = String(time.getDate()).padStart(2, '0');
  const year = String(time.getFullYear()).slice(2);

  const weekdays = ['일요일', '월요일', '화요일', '수요일', '목요일', '금요일', '토요일'];
  const weekday = weekdays[time.getDay()];

  const hoursValue = String(displayHours).padStart(2, '0');
  const minutesValue = String(minutes).padStart(2, '0');
  const secondsValue = String(seconds).padStart(2, '0');

  return (
    <div
      className="w-full h-full flex items-center justify-center px-4"
      style={{
        backgroundColor,
        backgroundImage: backgroundImage ? `url(${backgroundImage})` : undefined,
        backgroundSize: 'cover',
        backgroundPosition: 'center'
      }}
    >
      <div className="flex gap-4 md:gap-6">
        <div className="w-[45vw] md:w-[40vw] max-w-md" style={{ aspectRatio: '1 / 1' }}>
          <FlipDigit
            value={hoursValue}
            tileColor={tileColor}
            textColor={textColor}
            fontFamily={fontFamily}
            topContent={<div>{year}. {month}. {day}.</div>}
            bottomLeftContent={
              <button
                onClick={onToggleAmPm}
                className="hover:opacity-70 transition-opacity min-w-[56px] text-center"
              >
                {showAmPm ? (isPM ? "PM" : "AM") : "\u00A0"}
              </button>
            }
            subFontSize={subFontSize}
            subFontFamily={subFontFamily}
            subTextColor={textColor}
          />
        </div>

        <div className="w-[45vw] md:w-[40vw] max-w-md" style={{ aspectRatio: '1 / 1' }}>
          <FlipDigit
            value={minutesValue}
            tileColor={tileColor}
            textColor={textColor}
            fontFamily={fontFamily}
            topContent={<div>{weekday}</div>}
            bottomRightContent={
              <button
                onClick={onToggleSeconds}
                className="hover:opacity-70 transition-opacity min-w-[56px] text-center"
              >
                {showSeconds ? secondsValue : "\u00A0"}
              </button>
            }
            subFontSize={subFontSize}
            subFontFamily={subFontFamily}
            subTextColor={textColor}
          />
        </div>
      </div>
    </div>
  );
}
