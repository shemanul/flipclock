import { X, Upload } from 'lucide-react';
import { useRef } from 'react';

interface SettingsScreenProps {
  onClose: () => void;
  settings: Settings;
  onSettingsChange: (settings: Settings) => void;
}

export interface Settings {
  tileColor: string;
  textColor: string;
  backgroundColor: string;
  backgroundImage: string;
  fontFamily: string;
  subFontSize: string;
  subFontFamily: string;
  screenSaver: boolean;
  particleRefresh: boolean;
  keepScreenOn: boolean;
}

const themes = [
  { name: '기본', tileColor: '#0f4c5c', textColor: '#e5e5e5', backgroundColor: '#fb9189' },
  { name: '다크', tileColor: '#1a1a1a', textColor: '#ffffff', backgroundColor: '#2d2d2d' },
  { name: '블루', tileColor: '#1e3a8a', textColor: '#dbeafe', backgroundColor: '#3b82f6' },
  { name: '그린', tileColor: '#065f46', textColor: '#d1fae5', backgroundColor: '#10b981' },
  { name: '퍼플', tileColor: '#5b21b6', textColor: '#ede9fe', backgroundColor: '#a855f7' },
  { name: '오렌지', tileColor: '#9a3412', textColor: '#fed7aa', backgroundColor: '#f97316' },
];

const fonts = [
  { name: 'System UI', value: 'system-ui, -apple-system, BlinkMacSystemFont, sans-serif' },
  { name: 'Arial', value: 'Arial, Helvetica, sans-serif' },
  { name: 'Helvetica', value: 'Helvetica, Arial, sans-serif' },
  { name: 'Times New Roman', value: 'Times New Roman, Times, serif' },
  { name: 'Georgia', value: 'Georgia, serif' },
  { name: 'Courier New', value: 'Courier New, Courier, monospace' },
  { name: 'Monaco', value: 'Monaco, Consolas, monospace' },
  { name: 'Verdana', value: 'Verdana, Geneva, sans-serif' },
  { name: 'Trebuchet MS', value: 'Trebuchet MS, sans-serif' },
  { name: 'Impact', value: 'Impact, Charcoal, sans-serif' },
  { name: 'Comic Sans MS', value: 'Comic Sans MS, cursive' },
  { name: 'Palatino', value: 'Palatino Linotype, Book Antiqua, Palatino, serif' },
  { name: 'Garamond', value: 'Garamond, serif' },
  { name: 'Bookman', value: 'Bookman Old Style, serif' },
  { name: 'Tahoma', value: 'Tahoma, Geneva, sans-serif' },
  { name: 'Lucida', value: 'Lucida Sans Unicode, Lucida Grande, sans-serif' },
  { name: 'Monospace', value: 'ui-monospace, monospace' },
  { name: 'Serif', value: 'ui-serif, serif' },
  { name: 'Sans-serif', value: 'ui-sans-serif, sans-serif' },
  { name: 'Rounded', value: 'ui-rounded, sans-serif' },
];

export function SettingsScreen({ onClose, settings, onSettingsChange }: SettingsScreenProps) {
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (event) => {
        onSettingsChange({ ...settings, backgroundImage: event.target?.result as string });
      };
      reader.readAsDataURL(file);
    }
  };

  const getCurrentTime = () => {
    const now = new Date();
    const hours = now.getHours();
    const minutes = now.getMinutes();
    const seconds = now.getSeconds();
    const isPM = hours >= 12;
    const displayHours = hours % 12 || 12;

    const month = String(now.getMonth() + 1).padStart(2, '0');
    const day = String(now.getDate()).padStart(2, '0');
    const year = String(now.getFullYear()).slice(2);

    const weekdays = ['일요일', '월요일', '화요일', '수요일', '목요일', '금요일', '토요일'];
    const weekday = weekdays[now.getDay()];

    return {
      hours: String(displayHours).padStart(2, '0'),
      minutes: String(minutes).padStart(2, '0'),
      seconds: String(seconds).padStart(2, '0'),
      isPM,
      date: `${year}. ${month}. ${day}.`,
      weekday
    };
  };

  const time = getCurrentTime();

  return (
    <div className="w-full h-full flex flex-col bg-white/95 backdrop-blur-sm overflow-y-auto">
      <div className="sticky top-0 bg-white/95 border-b border-gray-200 p-4 flex items-center justify-between z-10">
        <h2 className="text-2xl">설정</h2>
        <button
          onClick={onClose}
          className="p-2 hover:bg-gray-100 rounded-full transition-colors"
        >
          <X className="w-6 h-6" />
        </button>
      </div>

      <div className="p-6 space-y-8">
        <div>
          <h3 className="text-xl mb-4">테마</h3>
          <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
            {themes.map((theme) => (
              <button
                key={theme.name}
                onClick={() =>
                  onSettingsChange({
                    ...settings,
                    tileColor: theme.tileColor,
                    textColor: theme.textColor,
                    backgroundColor: theme.backgroundColor,
                  })
                }
                className="p-4 rounded-lg border-2 transition-all hover:scale-105"
                style={{
                  backgroundColor: theme.backgroundColor,
                  borderColor:
                    settings.backgroundColor === theme.backgroundColor
                      ? theme.tileColor
                      : 'transparent',
                }}
              >
                <div
                  className="w-full h-12 rounded flex items-center justify-center mb-2"
                  style={{ backgroundColor: theme.tileColor, color: theme.textColor }}
                >
                  12
                </div>
                <div className="text-center text-sm" style={{ color: theme.tileColor }}>
                  {theme.name}
                </div>
              </button>
            ))}
          </div>
        </div>

        <div>
          <h3 className="text-xl mb-4">색상 커스터마이징</h3>
          <div className="space-y-4">
            <div>
              <label className="block text-sm mb-2">타일 색상</label>
              <input
                type="color"
                value={settings.tileColor}
                onChange={(e) =>
                  onSettingsChange({ ...settings, tileColor: e.target.value })
                }
                className="w-full h-12 rounded cursor-pointer"
              />
            </div>
            <div>
              <label className="block text-sm mb-2">글자 색상</label>
              <input
                type="color"
                value={settings.textColor}
                onChange={(e) =>
                  onSettingsChange({ ...settings, textColor: e.target.value })
                }
                className="w-full h-12 rounded cursor-pointer"
              />
            </div>
            <div>
              <label className="block text-sm mb-2">배경 색상</label>
              <input
                type="color"
                value={settings.backgroundColor}
                onChange={(e) =>
                  onSettingsChange({ ...settings, backgroundColor: e.target.value })
                }
                className="w-full h-12 rounded cursor-pointer"
              />
            </div>
          </div>
        </div>

        <div>
          <h3 className="text-xl mb-4">배경 이미지</h3>
          <div className="space-y-3">
            <input
              ref={fileInputRef}
              type="file"
              accept="image/*"
              onChange={handleImageUpload}
              className="hidden"
            />
            <button
              onClick={() => fileInputRef.current?.click()}
              className="w-full p-4 rounded-lg border-2 border-dashed border-gray-300 hover:border-gray-400 transition-colors flex items-center justify-center gap-2"
            >
              <Upload className="w-5 h-5" />
              <span>{settings.backgroundImage ? '다른 이미지 업로드' : '이미지 업로드'}</span>
            </button>
            {settings.backgroundImage && (
              <button
                onClick={() => onSettingsChange({ ...settings, backgroundImage: '' })}
                className="w-full p-2 rounded-lg bg-red-50 text-red-600 hover:bg-red-100 transition-colors"
              >
                배경 이미지 제거
              </button>
            )}
          </div>
        </div>

        <div>
          <h3 className="text-xl mb-4">시계 미리보기</h3>

          <div
            className="mb-4 mx-auto rounded-3xl overflow-hidden shadow-2xl"
            style={{
              width: '300px',
              height: '533px',
              backgroundColor: settings.backgroundColor,
              backgroundImage: settings.backgroundImage ? `url(${settings.backgroundImage})` : undefined,
              backgroundSize: 'cover',
              backgroundPosition: 'center'
            }}
          >
            <div className="w-full h-full flex items-center justify-center p-4">
              <div className="flex gap-3 w-full">
                <div className="flex-1 flex flex-col gap-[4px]" style={{ aspectRatio: '1 / 1' }}>
                  <div
                    className="flex-1 relative rounded-t-[28px] overflow-hidden shadow-xl"
                    style={{ backgroundColor: settings.tileColor }}
                  >
                    <div
                      className="absolute top-2 left-2 right-2 text-center z-20"
                      style={{
                        fontSize: `${parseInt(settings.subFontSize) * 0.7}px`,
                        fontFamily: settings.subFontFamily,
                        color: settings.textColor,
                        opacity: 0.9
                      }}
                    >
                      {time.date}
                    </div>

                    <div className="absolute inset-0 overflow-hidden">
                      <div className="absolute inset-0 flex items-end justify-center pb-2">
                        <span
                          style={{
                            color: settings.textColor,
                            fontFamily: settings.fontFamily,
                            fontWeight: '700',
                            fontSize: '4rem',
                            lineHeight: 1
                          }}
                        >
                          {time.hours}
                        </span>
                      </div>
                    </div>

                    <div className="absolute bottom-0 left-0 w-full h-[2px] bg-black/25 z-10" />
                    <div className="absolute bottom-0 left-0 w-full h-[18px] bg-gradient-to-t from-black/20 to-transparent z-10" />
                  </div>

                  <div
                    className="flex-1 relative rounded-b-[28px] overflow-hidden shadow-xl"
                    style={{ backgroundColor: settings.tileColor }}
                  >
                    <div className="absolute inset-0 overflow-hidden">
                      <div className="absolute inset-0 flex items-start justify-center pt-2">
                        <span
                          style={{
                            color: settings.textColor,
                            fontFamily: settings.fontFamily,
                            fontWeight: '700',
                            fontSize: '4rem',
                            lineHeight: 1
                          }}
                        >
                          {time.hours}
                        </span>
                      </div>
                    </div>

                    <div
                      className="absolute bottom-2 left-2 z-20"
                      style={{
                        fontSize: `${parseInt(settings.subFontSize) * 0.7}px`,
                        fontFamily: settings.subFontFamily,
                        color: settings.textColor,
                        opacity: 0.9
                      }}
                    >
                      {time.isPM ? 'PM' : 'AM'}
                    </div>

                    <div className="absolute top-0 left-0 w-full h-[2px] bg-black/25 z-10" />
                    <div className="absolute top-0 left-0 w-full h-[18px] bg-gradient-to-b from-black/20 to-transparent z-10" />
                  </div>
                </div>

                <div className="flex-1 flex flex-col gap-[4px]" style={{ aspectRatio: '1 / 1' }}>
                  <div
                    className="flex-1 relative rounded-t-[28px] overflow-hidden shadow-xl"
                    style={{ backgroundColor: settings.tileColor }}
                  >
                    <div
                      className="absolute top-2 left-2 right-2 text-center z-20"
                      style={{
                        fontSize: `${parseInt(settings.subFontSize) * 0.7}px`,
                        fontFamily: settings.subFontFamily,
                        color: settings.textColor,
                        opacity: 0.9
                      }}
                    >
                      {time.weekday}
                    </div>

                    <div className="absolute inset-0 overflow-hidden">
                      <div className="absolute inset-0 flex items-end justify-center pb-2">
                        <span
                          style={{
                            color: settings.textColor,
                            fontFamily: settings.fontFamily,
                            fontWeight: '700',
                            fontSize: '4rem',
                            lineHeight: 1
                          }}
                        >
                          {time.minutes}
                        </span>
                      </div>
                    </div>

                    <div className="absolute bottom-0 left-0 w-full h-[2px] bg-black/25 z-10" />
                    <div className="absolute bottom-0 left-0 w-full h-[18px] bg-gradient-to-t from-black/20 to-transparent z-10" />
                  </div>

                  <div
                    className="flex-1 relative rounded-b-[28px] overflow-hidden shadow-xl"
                    style={{ backgroundColor: settings.tileColor }}
                  >
                    <div className="absolute inset-0 overflow-hidden">
                      <div className="absolute inset-0 flex items-start justify-center pt-2">
                        <span
                          style={{
                            color: settings.textColor,
                            fontFamily: settings.fontFamily,
                            fontWeight: '700',
                            fontSize: '4rem',
                            lineHeight: 1
                          }}
                        >
                          {time.minutes}
                        </span>
                      </div>
                    </div>

                    <div
                      className="absolute bottom-2 right-2 z-20"
                      style={{
                        fontSize: `${parseInt(settings.subFontSize) * 0.7}px`,
                        fontFamily: settings.subFontFamily,
                        color: settings.textColor,
                        opacity: 0.9
                      }}
                    >
                      {time.seconds}
                    </div>

                    <div className="absolute top-0 left-0 w-full h-[2px] bg-black/25 z-10" />
                    <div className="absolute top-0 left-0 w-full h-[18px] bg-gradient-to-b from-black/20 to-transparent z-10" />
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div className="space-y-2 max-h-60 overflow-y-auto">
            {fonts.map((font) => (
              <button
                key={font.name}
                onClick={() =>
                  onSettingsChange({ ...settings, fontFamily: font.value })
                }
                className="w-full p-4 rounded-lg border-2 text-left transition-all hover:bg-gray-50"
                style={{
                  fontFamily: font.value,
                  borderColor:
                    settings.fontFamily === font.value ? settings.tileColor : '#e5e7eb',
                }}
              >
                {font.name}
              </button>
            ))}
          </div>
        </div>

        <div>
          <h3 className="text-xl mb-4">부가 정보 폰트</h3>
          <div className="space-y-2 max-h-60 overflow-y-auto">
            {fonts.map((font) => (
              <button
                key={font.name}
                onClick={() =>
                  onSettingsChange({ ...settings, subFontFamily: font.value })
                }
                className="w-full p-4 rounded-lg border-2 text-left transition-all hover:bg-gray-50"
                style={{
                  fontFamily: font.value,
                  borderColor:
                    settings.subFontFamily === font.value ? settings.tileColor : '#e5e7eb',
                }}
              >
                {font.name}
              </button>
            ))}
          </div>
        </div>

        <div>
          <h3 className="text-xl mb-4">부가 정보 글자 크기 (px)</h3>
          <div className="space-y-3">
            <input
              type="number"
              value={parseInt(settings.subFontSize)}
              onChange={(e) =>
                onSettingsChange({ ...settings, subFontSize: `${e.target.value}px` })
              }
              min="12"
              max="48"
              className="w-full p-4 rounded-lg border-2 border-gray-300 focus:border-blue-500 focus:outline-none text-lg"
            />
            <div className="text-sm text-gray-600 text-center">
              현재 크기: {parseInt(settings.subFontSize)}px (권장: 16-24px)
            </div>
          </div>
        </div>

        <div className="space-y-4">
          <h3 className="text-xl mb-4">화면 설정</h3>

          <div className="flex items-center justify-between p-4 rounded-lg bg-gray-50">
            <div>
              <div className="font-medium">화면 보호</div>
              <div className="text-sm text-gray-600">픽셀을 새로 고쳐 번인 방지</div>
            </div>
            <button
              onClick={() =>
                onSettingsChange({ ...settings, screenSaver: !settings.screenSaver })
              }
              className={`w-14 h-8 rounded-full transition-colors relative ${
                settings.screenSaver ? 'bg-blue-500' : 'bg-gray-300'
              }`}
            >
              <div
                className={`absolute top-1 w-6 h-6 bg-white rounded-full transition-transform ${
                  settings.screenSaver ? 'translate-x-7' : 'translate-x-1'
                }`}
              />
            </button>
          </div>

          <div className="flex items-center justify-between p-4 rounded-lg bg-gray-50">
            <div>
              <div className="font-medium">화면 입자로 픽셀 새로 고침</div>
              <div className="text-sm text-gray-600">파티클 효과로 픽셀 보호</div>
            </div>
            <button
              onClick={() =>
                onSettingsChange({
                  ...settings,
                  particleRefresh: !settings.particleRefresh,
                })
              }
              className={`w-14 h-8 rounded-full transition-colors relative ${
                settings.particleRefresh ? 'bg-blue-500' : 'bg-gray-300'
              }`}
            >
              <div
                className={`absolute top-1 w-6 h-6 bg-white rounded-full transition-transform ${
                  settings.particleRefresh ? 'translate-x-7' : 'translate-x-1'
                }`}
              />
            </button>
          </div>

          <div className="flex items-center justify-between p-4 rounded-lg bg-gray-50">
            <div>
              <div className="font-medium">화면 켜짐 유지</div>
              <div className="text-sm text-gray-600">절전모드 방지</div>
            </div>
            <button
              onClick={() =>
                onSettingsChange({
                  ...settings,
                  keepScreenOn: !settings.keepScreenOn,
                })
              }
              className={`w-14 h-8 rounded-full transition-colors relative ${
                settings.keepScreenOn ? 'bg-blue-500' : 'bg-gray-300'
              }`}
            >
              <div
                className={`absolute top-1 w-6 h-6 bg-white rounded-full transition-transform ${
                  settings.keepScreenOn ? 'translate-x-7' : 'translate-x-1'
                }`}
              />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}